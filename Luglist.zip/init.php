<?php
	$con=mysqli_connect("localhost","root","optimus","luglist") or 
	die(mysqli_error($con));
	global $message;
?>
